# Фото ИИ — Android-проект

Это исходный проект Android-приложения на Kotlin и backend на Node.js. Приложение принимает текстовое описание, отправляет его на ваш сервер и показывает созданное изображение.

## Важно

APK не должен содержать секретный API-ключ. Ключ хранится только на backend-сервере. Генерация через API может быть платной и требует активного доступа к API.

## 1. Запустите backend

Нужны Node.js 18+ и API-ключ с доступом к генерации изображений.

Linux/macOS:
```bash
cd backend
npm install
export OPENAI_API_KEY="ваш_api_ключ"
npm start
```

Windows PowerShell:
```powershell
cd backend
npm install
$env:OPENAI_API_KEY="ваш_api_ключ"
npm start
```

Опубликуйте backend на сервере с HTTPS. Локальный адрес `localhost` на телефоне означает сам телефон, а не ваш компьютер.

## 2. Подключите Android-приложение к серверу

Откройте `app/src/main/java/com/example/texttophotoai/MainActivity.kt` и замените:
```kotlin
private val apiUrl = "https://YOUR-SERVER.example.com/generate"
```
на реальный HTTPS-адрес вашего сервера, заканчивающийся на `/generate`.

## 3. Соберите APK

1. Установите Android Studio.
2. Откройте папку `TextToPhotoAI` как проект.
3. Дождитесь завершения Gradle Sync.
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK обычно появится в `app/build/outputs/apk/debug/app-debug.apk`.

Для публикации в Google Play нужно создать подписанную release-сборку и проверить актуальные требования магазина.

## Структура

- `app/` — Android-приложение.
- `backend/` — сервер, который безопасно обращается к API генерации изображений.

## Примечания

- Приложению нужен интернет.
- Это стартовый шаблон, а не готовый опубликованный сервис: сначала разверните backend и укажите его URL.
- Не публикуйте API-ключ в APK, Git-репозитории или клиентском коде.
