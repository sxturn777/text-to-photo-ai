import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("Set OPENAI_API_KEY in the environment before starting the server.");
  process.exit(1);
}

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/generate", async (req, res) => {
  try {
    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
    if (!prompt) return res.status(400).json({ error: "Введите текстовый запрос." });
    if (prompt.length > 4000) {
      return res.status(400).json({ error: "Запрос слишком длинный (максимум 4000 символов)." });
    }

    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-image-1",
        prompt,
        size: "1024x1024"
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("Image API error:", data);
      return res.status(response.status).json({
        error: data?.error?.message || "Сервис генерации изображений вернул ошибку."
      });
    }

    const imageBase64 = data?.data?.[0]?.b64_json;
    if (!imageBase64) {
      return res.status(502).json({ error: "Сервис не вернул изображение." });
    }
    res.json({ image_base64: imageBase64 });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Внутренняя ошибка сервера." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Image backend listening on port ${port}`));
