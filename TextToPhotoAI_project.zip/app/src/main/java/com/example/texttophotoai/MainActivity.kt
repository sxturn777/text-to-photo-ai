package com.example.texttophotoai

import android.app.Activity
import android.os.Bundle
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // Укажите URL своего backend-сервера после его запуска. Используйте HTTPS в продакшене.
    private val apiUrl = "https://YOUR-SERVER.example.com/generate"
    private lateinit var promptInput: EditText
    private lateinit var generateButton: Button
    private lateinit var statusText: TextView
    private lateinit var resultImage: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Фото ИИ"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        layout.addView(title, matchWidth(60))

        val subtitle = TextView(this).apply {
            text = "Опишите изображение, которое хотите создать"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        layout.addView(subtitle, matchWidth(54))

        promptInput = EditText(this).apply {
            hint = "Например: уютный дом у озера на закате, фотореализм"
            minLines = 3
            maxLines = 5
            gravity = Gravity.TOP
            setPadding(16, 14, 16, 14)
        }
        layout.addView(promptInput, matchWidth(130))

        generateButton = Button(this).apply {
            text = "Создать изображение"
            setOnClickListener { generateImage() }
        }
        layout.addView(generateButton, matchWidth(58))

        statusText = TextView(this).apply {
            text = "Введите описание и нажмите кнопку."
            textSize = 14f
            gravity = Gravity.CENTER
        }
        layout.addView(statusText, matchWidth(56))

        resultImage = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Созданное изображение"
        }
        layout.addView(resultImage, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(layout)
    }

    private fun matchWidth(height: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, height
        ).apply { bottomMargin = 10 }

    private fun generateImage() {
        val prompt = promptInput.text.toString().trim()
        if (prompt.isBlank()) {
            promptInput.error = "Сначала напишите, что нужно нарисовать"
            return
        }
        if (apiUrl.contains("YOUR-SERVER")) {
            statusText.text = "Сначала настройте адрес backend-сервера в MainActivity.kt"
            return
        }

        generateButton.isEnabled = false
        statusText.text = "ИИ создаёт изображение… Это может занять некоторое время."
        resultImage.setImageDrawable(null)

        thread {
            try {
                val connection = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 180000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                connection.outputStream.use {
                    it.write(JSONObject().put("prompt", prompt).toString().toByteArray(Charsets.UTF_8))
                }

                val stream = if (connection.responseCode in 200..299)
                    connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (connection.responseCode !in 200..299) {
                    throw Exception(JSONObject(response).optString("error", "Ошибка сервера"))
                }

                val base64 = JSONObject(response).getString("image_base64")
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw Exception("Не удалось открыть изображение")

                runOnUiThread {
                    resultImage.setImageBitmap(bitmap)
                    statusText.text = "Готово!"
                    generateButton.isEnabled = true
                }
                connection.disconnect()
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Не получилось создать изображение: ${e.message ?: "проверьте соединение"}"
                    generateButton.isEnabled = true
                }
            }
        }
    }
}
